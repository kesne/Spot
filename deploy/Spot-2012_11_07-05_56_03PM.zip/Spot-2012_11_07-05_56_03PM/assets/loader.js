window.onload = function(){
	new App().renderInto(document.body);
}